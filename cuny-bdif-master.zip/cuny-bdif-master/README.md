#Big Data in Finance#
##Masters in Financial Engineering##
(Baruch CUNY MFE 9898)
